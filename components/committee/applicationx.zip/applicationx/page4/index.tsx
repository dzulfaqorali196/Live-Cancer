"use client";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { StepData, pageSchemas } from "../schema";
import { useFormContext } from "../form-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { useRouter } from "next/navigation";
// import { useEffect } from "react";
import { Routes } from "@/constants/routes";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
// import { useSession } from "next-auth/react";

const contributionOptions = [
  "Reviewing applications for funding",
  "Scientific advisory for selected projects",
  "Governance and protocol development",
  "Community-building / education",
  "Public speaking / representation of CancerFun",
  "Networking with funders or researchers",
];

type FormData = StepData["step4"];

export default function ApplicationFormPage4() {
  const router = useRouter();
  // const pathname = usePathname();

  // const { status } = useSession();
  const { formData, updateFormData } = useFormContext();

  // useEffect(() => {
  //   if (status === "unauthenticated") {
  //     router.push(`${Routes.SIGNIN}?callbackUrl=${pathname}`);
  //   }
  // }, [status, router, pathname]);

  const form = useForm<FormData>({
    resolver: yupResolver(pageSchemas.step4),
    defaultValues: {
      hoursPerMonth: formData?.hoursPerMonth ?? 1,
      contributions: formData?.contributions ?? [],
      conflictOfInterest: formData?.conflictOfInterest ?? "no",
    },
  });

  const prevPageUrl = `${Routes.COMMITTEE_APPLICATION}/page/2`;
  const nextPageUrl = `${Routes.COMMITTEE_APPLICATION}/page/4`;

  const onSubmit = (data: FormData) => {
    updateFormData(data);
    router.push(nextPageUrl);
  };

  return (
    <div className="flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Involvement & Availability</CardTitle>
          <CardDescription>
            Please specify your availability and areas of contribution.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="hoursPerMonth"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      How many hours per month can you realistically contribute?
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="10"
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="contributions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Which of the following are you interested in contributing
                      to? (Check all that apply)
                    </FormLabel>
                    <div className="space-y-2">
                      {contributionOptions.map((option) => (
                        <FormItem
                          key={option}
                          className="flex items-center space-x-2"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value.includes(option)}
                              onCheckedChange={(checked) => {
                                const newValue = checked
                                  ? [...field.value, option]
                                  : field.value.filter(
                                      (val: string) => val !== option
                                    );
                                field.onChange(newValue);
                              }}
                            />
                          </FormControl>
                          <FormLabel className="font-normal">
                            {option}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="conflictOfInterest"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Are you currently involved in any organizations that could
                      present a conflict of interest?
                    </FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex space-x-4"
                      >
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <RadioGroupItem value="yes" />
                          </FormControl>
                          <FormLabel className="font-normal">Yes</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <RadioGroupItem value="no" />
                          </FormControl>
                          <FormLabel className="font-normal">No</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.push(prevPageUrl)}
                >
                  Previous
                </Button>
                <Button type="submit">Next</Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
