import * as yup from "yup";

export const schema = yup
  .object({
    fullName: yup
      .string()
      .required("Full name is required")
      .min(2, "Name must be at least 2 characters"),
    email: yup
      .string()
      .email("Invalid email address")
      .required("Email is required"),
    preferredContact: yup
      .string()
      .required("Preferred contact method is required"),
    country: yup.string().required("Country is required"),
    affiliation: yup.string().optional().default(""),
    title: yup.string().optional().default(""),
    currentRole: yup.string().required("Current role is required"),
    educationalBackground: yup
      .string()
      .required("Educational background is required"),
    expertise: yup.string().required("Field(s) of expertise is required"),
    cancerResearch: yup
      .string()
      .oneOf(["yes", "no"], "Please select an option")
      .required("This field is required"),
    publications: yup
      .string()
      .url("Must be a valid URL")
      .required("At least one link is required"),
    previousExperience: yup.string().optional().default(""),
    motivation: yup
      .string()
      .required("Motivation is required")
      .max(250, "Must be 250 words or less"),
    perspectives: yup.string().required("Perspectives are required"),
    decentralization: yup
      .string()
      .required("Decentralization view is required"),
    hoursPerMonth: yup
      .number()
      .required("Hours per month is required")
      .min(1, "Must commit at least 1 hour"),
    contributions: yup
      .array()
      .of(yup.string().required())
      .min(1, "Select at least one contribution")
      .required("Contributions are required"),
    conflictOfInterest: yup
      .string()
      .oneOf(["yes", "no"], "Please select an option")
      .required("This field is required"),
    additionalInfo: yup.string().optional().default(""),
    cvLink: yup.string().url("Must be a valid URL").optional().default(""),
  })
  .required();

export const pageSchemas = {
  step1: schema.pick([
    "fullName",
    "email",
    "preferredContact",
    "country",
    "affiliation",
    "title",
  ]),
  step2: schema.pick([
    "currentRole",
    "educationalBackground",
    "expertise",
    "cancerResearch",
    "publications",
    "previousExperience",
  ]),
  step3: schema.pick(["motivation", "perspectives", "decentralization"]),
  step4: schema.pick(["hoursPerMonth", "contributions", "conflictOfInterest"]),
  step5: schema.pick(["additionalInfo", "cvLink"]),
} as const;

export type StepData = {
  step1: yup.InferType<typeof pageSchemas.step1>;
  step2: yup.InferType<typeof pageSchemas.step2>;
  step3: yup.InferType<typeof pageSchemas.step3>;
  step4: yup.InferType<typeof pageSchemas.step4>;
  step5: yup.InferType<typeof pageSchemas.step5>;
};
