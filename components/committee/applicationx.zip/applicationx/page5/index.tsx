"use client";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { StepData, pageSchemas } from "../schema";
import { useFormContext } from "../form-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useRouter } from "next/navigation";
import { Routes } from "@/constants/routes";

type FormData = StepData["step5"];

export default function ApplicationFormPage5() {
  const router = useRouter();
  // const pathname = usePathname();

  // const { data: session, status } = useSession();
  const { formData, updateFormData } = useFormContext();
  // const queryClient = useQueryClient();
  // const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: yupResolver(pageSchemas.step5),
    defaultValues: {
      additionalInfo: formData.additionalInfo ?? "",
      cvLink: formData.cvLink ?? "",
    },
  });

  const jobId = "623e95f0-e574-4f06-a120-ec46449f4976";

  // useEffect(() => {
  //   if (status === "unauthenticated") {
  //     router.push(`${Routes.SIGNIN}?callbackUrl=${pathname}`);
  //   }
  // }, [status, router, pathname]);

  const prevPageUrl = `${Routes.COMMITTEE_APPLICATION}/page/2`;
  const nextPageUrl = `${Routes.COMMITTEE_APPLICATION}/thanks`;

  const onSubmit = (data: FormData) => {
    console.log("-------data to save--------", data);
    updateFormData(data);
  };

  return (
    <div className="flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Optional Information</CardTitle>
          <CardDescription>
            Provide any additional information or documents.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="additionalInfo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Is there anything else you’d like to share with us?
                      (Optional)
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Any additional details..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="cvLink"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Attach your CV / Resume or academic bio (PDF or link,
                      Optional)
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="https://example.com/cv.pdf"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.push(prevPageUrl)}
                >
                  Previous
                </Button>
                <Button type="submit">Submit Application</Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
