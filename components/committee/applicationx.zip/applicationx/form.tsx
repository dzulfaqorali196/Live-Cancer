"use client";

import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { applicationFormSchema } from "@/components/committee/application/yup-schema";
import { ApplicationFormData } from "@/components/committee/application/form-data";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormSection1 } from "@/components/committee/application/form-section-1";

export default function ApplicationForm() {
  const form = useForm<ApplicationFormData>({
    resolver: yupResolver(applicationFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      preferredContact: "",
      country: "",
      affiliation: "",
      title: "",
    },
  });

  const onSubmit = (data: ApplicationFormData) => {
    console.log("Form submitted:", data);
    // Handle form submission (e.g., API call)
    form.reset();
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid md:grid-cols-2 gap-12 items-start max-w-5xl mx-auto">
          <div className="order-2 lg:order-1">
            <FormSection1 form={form} />
          </div>
          <div className="order-1 lg:order-2">x</div>
        </div>
        <div className="max-w-5xl mx-auto flex flex-row justify-between">
          <div className="text-sm">
            This form is for those interested in becoming part of the CancerFun
            Committee a group of experts who will help evaluate research
            proposals, advise on scientific and strategic direction, and
            represent the ethos of open, permissionless science.
          </div>
          <div>
            <Button type="submit" className="w-full min-w-40">
              Submit Application
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
