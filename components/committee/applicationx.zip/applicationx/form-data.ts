export interface ApplicationFormData {
  fullName: string;
  email: string;
  preferredContact: string;
  country: string;
  affiliation?: string;
  title?: string;
}
