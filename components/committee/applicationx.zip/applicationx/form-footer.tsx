export default function ApplicationFormFooter() {
  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex flex-col items-center justify-center gap-6 text-sm">
        <p>
          Thank you for your interest in joining the CancerFun Committee. This
          application form consists of 5 pages. You may pause and resume at any
          time.
        </p>
        <p>
          This form is for those interested in becoming part of the CancerFun
          Committee, a group of experts who will help evaluate research
          proposals, advise on scientific and strategic direction, and represent
          the ethos of open, permissionless science.
        </p>
      </div>
    </div>
  );
}
