import * as yup from "yup";

export const applicationFormSchema = yup
  .object({
    fullName: yup
      .string()
      .required("Full name is required")
      .min(2, "Name must be at least 2 characters"),
    email: yup
      .string()
      .email("Invalid email address")
      .required("Email is required"),
    preferredContact: yup
      .string()
      .required("Preferred contact method is required"),
    country: yup.string().required("Country is required"),
  })
  .required();
