"use client";

import { schema } from "@/components/committee/application/schema";
import { createContext, useContext, useState, ReactNode } from "react";
import { InferType } from "yup";

type FormData = InferType<typeof schema>;

interface FormContextType {
  formData: FormData;
  updateFormData: (data: Partial<FormData>) => void;
  resetFormData: () => void;
}

const defaultFormData: FormData = {
  fullName: "",
  email: "",
  preferredContact: "",
  country: "",
  affiliation: "",
  title: "",
  currentRole: "",
  educationalBackground: "",
  expertise: "",
  cancerResearch: "no",
  publications: "",
  previousExperience: "",
  motivation: "",
  perspectives: "",
  decentralization: "",
  hoursPerMonth: 0,
  contributions: [],
  conflictOfInterest: "no",
  additionalInfo: "",
  cvLink: "",
};

const FormContext = createContext<FormContextType | undefined>(undefined);

/*
export function FormProvider({ children }: { children: ReactNode }) {
  const [formData, setFormData] = useState<FormData>(defaultFormData);

  const updateFormData = (data: Partial<FormData>) => {
    setFormData((prev) => ({ ...prev, ...data }));
  };

  const resetFormData = () => {
    setFormData(defaultFormData);
  };

  return (
    <FormContext.Provider value={{ formData, updateFormData, resetFormData }}>
      {children}
    </FormContext.Provider>
  );
}
*/

export function FormProvider({ children }: { children: ReactNode }) {
  const [formData, setFormData] = useState<FormData>(defaultFormData);

  const updateFormData = (data: Partial<FormData>) => {
    setFormData((prev) => ({ ...prev, ...data }));
  };

  const resetFormData = () => {
    setFormData(defaultFormData);
  };

  return (
    <FormContext.Provider value={{ formData, updateFormData, resetFormData }}>
      {children}
    </FormContext.Provider>
  );
}

export function useFormContext() {
  const context = useContext(FormContext);
  if (!context) {
    throw new Error("useFormContext must be used within a FormProvider");
  }
  return context;
}
